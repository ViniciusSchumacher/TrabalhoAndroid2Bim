package com.example.exemploactivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;

import com.example.adapters.AlunoAdapter;
import com.model.Aluno;
import com.util.Globais;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class ListaAlunoPorDisciplinaActivity extends AppCompatActivity {

    private Spinner spDisciplina;
    private ListView lvAlunos;
    private AlunoAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_aluno_por_disciplina);

        spDisciplina = findViewById(R.id.spDisciplina);
        lvAlunos = findViewById(R.id.lvAlunos);

        ArrayAdapter<CharSequence> adapterDisciplina = ArrayAdapter.createFromResource(this,
                R.array.disciplinas_array, android.R.layout.simple_spinner_item);
        adapterDisciplina.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spDisciplina.setAdapter(adapterDisciplina);

        spDisciplina.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String disciplinaSelecionada = parent.getItemAtPosition(position).toString();
                filtrarAlunosPorDisciplina(Aluno.Disciplina.valueOf(disciplinaSelecionada));
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    private void filtrarAlunosPorDisciplina(Aluno.Disciplina disciplina){
        if(Globais.listAlunos == null){
            Globais.listAlunos = new ArrayList<>();
        }
        List<Aluno> alunosFiltrados = Globais.listAlunos.stream()
                .filter(aluno -> aluno.getDisciplina().equals(disciplina))
                .collect(Collectors.toList());

        AlunoAdapter adapter = new AlunoAdapter(this, new ArrayList<>(alunosFiltrados));
        lvAlunos.setAdapter(adapter);
    }

}
