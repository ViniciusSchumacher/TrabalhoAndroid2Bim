package com.example.exemploactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.util.Globais;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private Button btCadastro;
    private Button btListaAlunos;
    private Button btnListaAlunosPorDisciplina;
    private Button btnListaNotaPorAluno;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (Globais.listAlunos == null) {
            Globais.listAlunos = new ArrayList<>();
        }

        btCadastro = findViewById(R.id.btnCadastro);
        btListaAlunos = findViewById(R.id.btnLista);
        btnListaAlunosPorDisciplina = findViewById(R.id.btnListaAlunosPorDisciplina);
        btnListaNotaPorAluno = findViewById(R.id.btnListaNotaPorAluno);

        btCadastro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                abrirCadastro();
            }
        });

        btListaAlunos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                abrirLista();
            }
        });

        btnListaAlunosPorDisciplina.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirListaPorDisciplina();
            }
        });

        btnListaNotaPorAluno.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirListaNotaPorAluno();
            }
        });
    }

    private void abrirCadastro(){
        Intent intent = new Intent(this,CadastroActivity.class);

        startActivity(intent);
    }

    private void abrirLista(){
        Intent intent = new Intent(this,ListaAlunoActivity.class);

        startActivity(intent);
    }

    private void abrirListaPorDisciplina(){
        Intent intent = new Intent(MainActivity.this, ListaAlunoPorDisciplinaActivity.class);

        startActivity(intent);
    }

    private void abrirListaNotaPorAluno(){
        Intent intent = new Intent(MainActivity.this, ListaNotaPorAlunoActivity.class);

        startActivity(intent);
    }


}