package com.model;

public class Aluno {

    public enum Disciplina {
        MATEMATICA, PORTUGUES, GEOGRAFIA, HISTORIA, CIENCIAS
    }

    private int ra;
    private String nome;
    private Disciplina disciplina;
    private double nota;

    public enum Bimestre {
        BIMESTRE_1, BIMESTRE_2, BIMESTRE_3, BIMESTRE_4
    }

    private Bimestre bimestre;

    public Bimestre getBimestre() {
        return bimestre;
    }

    public void setBimestre(Bimestre bimestre) {
        this.bimestre = bimestre;
    }


    public int getRa() {
        return ra;
    }

    public void setRa(int ra) {
        this.ra = ra;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Disciplina getDisciplina() {
        return disciplina;
    }

    public void setDisciplina(Disciplina disciplina) {
        this.disciplina = disciplina;
    }

    public double getNota() {
        return nota;
    }

    public void setNota(double nota) {
        this.nota = nota;
    }


    public Aluno(int ra, String nome, Disciplina disciplina, double nota, int bimestre) {
        this.ra = ra;
        this.nome = nome;
        this.disciplina = disciplina;
        this.nota = nota;
    }

    public Aluno() {
    }

    @Override
    public String toString() {
        return "Aluno{" +
                "ra=" + ra +
                ", nome='" + nome + '\'' +
                ", disciplina=" + disciplina +
                ", nota=" + nota +
                ", bimestre=" + bimestre +
                '}';
    }
}
