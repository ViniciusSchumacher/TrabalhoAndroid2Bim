package com.example.exemploactivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;

import com.example.adapters.AlunoAdapter;
import com.example.exemploactivity.R;
import com.model.Aluno;
import com.util.Globais;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class ListaNotaPorAlunoActivity extends AppCompatActivity {

    private Spinner spAluno;
    private ListView lvNotas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_nota_por_aluno);

        spAluno = findViewById(R.id.spAluno);
        lvNotas = findViewById(R.id.lvNotas);

        List<String> alunos = Globais.listAlunos.stream()
                .map(Aluno::getNome)
                .distinct()
                .collect(Collectors.toList());

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, alunos);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spAluno.setAdapter(adapter);

        spAluno.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String alunoSelecionado = parent.getItemAtPosition(position).toString();
                filtrarNotasPorAluno(alunoSelecionado);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // do nothing
            }
        });
    }

    private void filtrarNotasPorAluno(String alunoNome) {
        List<Aluno> alunosFiltrados = Globais.listAlunos.stream()
                .filter(aluno -> aluno.getNome().equals(alunoNome))
                .collect(Collectors.toList());

        AlunoAdapter adapter = new AlunoAdapter(this, new ArrayList<>(alunosFiltrados));
        lvNotas.setAdapter(adapter);
    }
}
