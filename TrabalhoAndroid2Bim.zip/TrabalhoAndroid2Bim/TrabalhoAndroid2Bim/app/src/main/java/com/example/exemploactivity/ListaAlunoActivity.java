package com.example.exemploactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import com.example.adapters.AlunoAdapter;
import com.util.Globais;

import java.util.ArrayList;

public class ListaAlunoActivity extends AppCompatActivity {

    private ListView lvAlunos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_aluno);

        lvAlunos = findViewById(R.id.lvAlunos);

        if (Globais.listAlunos == null) {
            Globais.listAlunos = new ArrayList<>();
        }
        AlunoAdapter adapter = new AlunoAdapter(this, Globais.listAlunos);

        lvAlunos.setAdapter(adapter);

    }
}