package com.util;

import com.model.Aluno;

import java.util.ArrayList;

public class Globais {

    public static ArrayList<Aluno> listAlunos;
}
