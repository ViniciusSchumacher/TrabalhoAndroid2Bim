package com.example.exemploactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import android.widget.ArrayAdapter;

import com.model.Aluno;
import com.util.Globais;

import java.util.ArrayList;

public class CadastroActivity extends AppCompatActivity {

    private EditText edRa;
    private EditText edNome;
    private Spinner spDisciplina;
    private EditText edNota;
    private Spinner spBimestre;
    private Button btSalvar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);

        edNome = findViewById(R.id.edNome);
        edRa = findViewById(R.id.edRA);
        spDisciplina = findViewById(R.id.spDisciplina);
        edNota = findViewById(R.id.edNota);
        spBimestre = findViewById(R.id.spinnerBimestre);
        btSalvar = findViewById(R.id.btnSalvar);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.disciplinas_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spDisciplina.setAdapter(adapter);

        ArrayAdapter<Aluno.Bimestre> adapterBimestre = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, Aluno.Bimestre.values());
        adapterBimestre.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spBimestre.setAdapter(adapterBimestre);

        if(Globais.listAlunos == null)
            Globais.listAlunos = new ArrayList<>();

        btSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                salvarAluno();
            }
        });
    }

    private void salvarAluno(){
        Aluno aluno = new Aluno();
        aluno.setRa(Integer.parseInt(edRa.getText().toString()));
        aluno.setNome(edNome.getText().toString());
        aluno.setDisciplina(Aluno.Disciplina.valueOf(spDisciplina.getSelectedItem().toString()));
        aluno.setNota(Double.parseDouble(edNota.getText().toString()));
        aluno.setBimestre((Aluno.Bimestre) spBimestre.getSelectedItem());

        Globais.listAlunos.add(aluno);

        Toast.makeText(this, "Aluno salvo com sucesso!", Toast.LENGTH_LONG).show();

        finish();
    }
}
