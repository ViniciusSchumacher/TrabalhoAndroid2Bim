package com.example.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.exemploactivity.R;
import com.model.Aluno;

import java.util.ArrayList;

public class AlunoAdapter extends BaseAdapter {

    private Context context;
    private ArrayList<Aluno> lista;

    public AlunoAdapter(Context context, ArrayList<Aluno> lista) {
        this.context = context;
        this.lista = lista;
    }

    @Override
    public int getCount(){
        return lista.size();
    }

    @Override
    public Object getItem(int i){
        return lista.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        if(view == null){
            view = LayoutInflater.from(context).inflate(R.layout.item_list_aluno,viewGroup, false);
        }
        Aluno aluno = lista.get(i);

        TextView tvNomeAluno = view.findViewById(R.id.tvNomeAluno);
        TextView tvRaAluno = view.findViewById(R.id.tvRaAluno);
        TextView tvDisciplinaAluno = view.findViewById(R.id.tvDisciplinaAluno);
        TextView tvNotaAluno = view.findViewById(R.id.tvNotaAluno);
        TextView tvBimestreAluno = view.findViewById(R.id.tvBimestreAluno);

        tvRaAluno.setText(String.valueOf(aluno.getRa()));
        tvNomeAluno.setText(aluno.getNome());
        tvDisciplinaAluno.setText(aluno.getDisciplina().toString());
        tvNotaAluno.setText(String.valueOf(aluno.getNota()));
        tvBimestreAluno.setText(String.valueOf(aluno.getBimestre()));

        return view;
    }
}
